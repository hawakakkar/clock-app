import React, { useState, useEffect } from "react";
import "./App.css";

function App() {
  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    return hour >= 6 && hour < 18 ? "day" : "night";
  };

  const toggleDetails = () => {
    setIsExpanded(!isExpanded);
  };

  const [timeOfDay, setTimeOfDay] = useState(getTimeOfDay());
  const [isExpanded, setIsExpanded] = useState(false);
  const [time, setTime] = useState(new Date());

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
      setTimeOfDay(getTimeOfDay());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formattedTime = time.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  const dayOfYear = Math.floor(
    (new Date() - new Date(new Date().getFullYear(), 0, 0)) /
      (1000 * 60 * 60 * 24),
  );

  const dayOfWeek = time.getDay();
  const weekNumber = Math.ceil(dayOfYear / 7);

  return (
    <div className={`app ${timeOfDay} ${isExpanded ? "expanded" : ""}`}>
      {/* The Overlay */}
      <div className="overlay">
        {/* The Quote */}
        <div className="quote">
          <p>
            “The science of operations, as derived from mathematics more
            especially, is a science of itself, and has its own abstract truth
            and value.”
          </p>
          <span>Ada Lovelace</span>
        </div>

        {/* The Time Section */}
        <div className="time-section">
          <p className="greeting">
            {timeOfDay === "day"
              ? "☀️ GOOD MORNING, IT’S CURRENTLY"
              : "🌙 GOOD EVENING, IT’S CURRENTLY"}
          </p>

          <h1 className="time">
            {formattedTime} <span>BST</span>
          </h1>

          <p className="location"> IN Afghanistan, Kabul</p>
        </div>

        {}

        <button className="toggle-btn" onClick={toggleDetails}>
          {isExpanded ? "LESS" : "MORE"}

          <img
            src={
              isExpanded
                ? "/desktop/icon-arrow-up.svg"
                : "/desktop/icon-arrow-down.svg"
            }
            alt="arrow"
            className={isExpanded ? "arrow-icon" : "arrow-icon more-arrow"}
          />
        </button>
      </div>

      {}
      {isExpanded && (
        <div className="details">
          <div>
            <p>CURRENT TIMEZONE</p>
            <h2>Asia/Afghanistan</h2>
          </div>

          <div>
            <p>DAY OF THE YEAR</p>
            <h2>{dayOfYear}</h2>
          </div>

          <div>
            <p>DAY OF THE WEEK</p>
            <h2>{dayOfWeek}</h2>
          </div>

          <div>
            <p>WEEK NUMBER</p>
            <h2>{weekNumber}</h2>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
